import { getGenerations } from "../../lib/queries";
export default async function GenerationsPage() {
  const rows = await getGenerations();
  return (
    <main>
      <h1>Saved generations</h1>
      {/* TODO: render only the current tenant's generations */}
      <ul>{rows.map((r: any) => <li key={r.id}>{r.prompt}</li>)}</ul>
    </main>
  );
}
