import { supabase } from "./supabase";
// TODO: scope this to the current tenant. As written it leaks every tenant's rows.
export async function getGenerations() {
  const { data } = await supabase.from("generations").select("*");
  return data ?? [];
}
