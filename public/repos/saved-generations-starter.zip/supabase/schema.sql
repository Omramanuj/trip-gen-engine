-- TODO: finish this. The RLS policy is missing — right now ANY tenant can read ALL rows.
create table if not exists generations (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  prompt text not null,
  output text not null,
  created_at timestamptz default now()
);

alter table generations enable row level security;

-- TODO: add a policy so a row is only visible to its own tenant.
-- create policy "tenant_isolation" on generations
--   for select using ( tenant_id = ??? );
