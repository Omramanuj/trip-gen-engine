# Saved AI Generations — starter

Wire per-tenant *Saved Generations* end-to-end. Two tenants must NEVER see each
other's rows.

Your job:
1. `supabase/schema.sql` — finish the table + an RLS policy keyed on tenant_id.
2. `lib/queries.ts` — fetch only the current tenant's generations.
3. `app/generations/page.tsx` — render them.

Run: `pnpm i && pnpm dev`. Submit your work as a .zip.
