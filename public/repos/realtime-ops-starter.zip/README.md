# realtime-ops-starter

A minimal realtime doc-editing op pipeline. Clients send `Op`s over a websocket;
the server persists, applies, and broadcasts them. Under reconnects, clients
REPLAY unacked ops -- so apply must be idempotent. Right now it is NOT.

Your job (make it idempotent end to end):
1. `db/schema.sql` - the `ops` table has NO idempotency constraint. Add a UNIQUE
   key on the durable identity of a logical edit: (doc_id, client_id, client_seq).
2. `src/apply-op.ts` - dedups on `op.id`, which is minted fresh on every retry.
   Dedup on (client_id, client_seq) instead so replays are no-ops.
3. `src/ws-server.ts` - ack/replay path. Persist before ack; ensure a replayed
   op does not double-apply.

Done = a replayed op is a no-op: same row count, same doc revision. Submit your
work as a .zip.

Run: `pnpm i && pnpm test` (the replay test currently fails: applies twice).
