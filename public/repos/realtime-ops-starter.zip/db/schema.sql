-- TODO: the ops table is missing its idempotency constraint.
-- A logical edit is identified by (doc_id, client_id, client_seq) and is stable
-- across retries/replays. Add a UNIQUE constraint on those columns so a replay
-- can be suppressed with ON CONFLICT ... DO NOTHING.
create table ops (
  server_op_id uuid primary key default gen_random_uuid(),
  doc_id       uuid not null,
  client_id    uuid not null,
  client_seq   bigint not null,
  kind         text not null,
  payload      jsonb not null,
  created_at   timestamptz not null default now()
);

-- TODO: create unique index ops_idem on ops (doc_id, client_id, client_seq);
