import type { Op } from './types';

const doc = { ops: [] as Op[], revision: 0 };

// BUG: dedups on op.id, which is minted fresh on every replay, so a replayed
// op is treated as new and applied twice. Dedup on (clientId, clientSeq).
const appliedOps = new Set<string>();

export function applyOp(op: Op): void {
  if (appliedOps.has(op.id)) return;   // <-- wrong key
  appliedOps.add(op.id);
  doc.ops.push(op);
  doc.revision += 1;
}

export function getDoc() { return doc; }
