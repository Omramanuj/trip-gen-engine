import type { Op } from './types';
import { applyOp } from './apply-op';

// Toy handler. On reconnect the client replays unacked ops; each replay carries
// the same clientSeq but a fresh `id`. applyOp must make that a no-op.
export function onMessage(op: Op) {
  applyOp(op);
  // ack(op.clientSeq)
}
