export type OpKind = 'insert' | 'delete' | 'format';

export type Op = {
  // Fresh per SEND. Changes on every retry/replay. Not a stable edit identity.
  id: string;
  docId: string;
  clientId: string;
  // Stable per-client sequence for the logical edit; survives retries.
  clientSeq: number;
  kind: OpKind;
  payload: unknown;
};
