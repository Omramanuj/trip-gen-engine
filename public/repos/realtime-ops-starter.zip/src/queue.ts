import type { Op } from './types';
import { applyOp } from './apply-op';

// A background worker also re-applies ops to rebuild a snapshot. It has no
// websocket session -- so any dedup that lives only in the socket layer will
// NOT protect this path. Idempotency must be durable (DB), not per-connection.
export function rebuildSnapshot(ops: Op[]) {
  for (const op of ops) applyOp(op);
}
